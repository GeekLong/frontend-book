import Vue from 'vue';
// import WgPaper from './wg-paper.vue';
// Vue.component('wg-paper', WgPaper);