<template>
    <nuxt/>
</template>

<style lang="scss">
    body ,a{
        height: 100%;
        margin: 0px;
        padding: 0px;
        font-size: 14px;
        color: #333;
        font-family: PingFang SC, Microsoft YaHei, simhei, Helvetica, Arial, sans-serif;
        -webkit-font-smoothing: antialiased;
        -webkit-text-size-adjust: 100%;
    }
    .container {
        width: 1100px;
        min-width: 1100px;
        position: relative;
        margin: 0 auto;
    }
   a,
    a:link {
        -webkit-appearance: none;
        text-decoration: none;
        color: #333;
        cursor: pointer;
    }
    img {
        border: none;
    }
    h2 {
        margin: 0px;
    }
    
    div,
    select,
    input[type="text"],
    input[type="number"],
    input[type="tel"],
    input[type="email"],
    input[type="checkbox"],
    input[type="radio"] {
        -webkit-appearance: none;
    }
    
    div:focus,
    input:focus,
    select:focus,
    textarea:focus {
        outline-width: 0;
        box-shadow: none;
    }
    
    input:required {
        //去除 firefox 浏览器红色边框
        box-shadow: none;
    }
    button {
        border: none;
        outline-width: 0;
        box-shadow: none;
    }

</style>