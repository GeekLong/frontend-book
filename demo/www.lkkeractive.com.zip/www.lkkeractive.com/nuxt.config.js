const pkg = require('./package.json');
const webpack = require('webpack');
const path = require('path');
const resolve = file => path.resolve(__dirname, file);

module.exports = {
    srcDir: 'src/',
    dir: {
        static: resolve('./static/')
    },
    build: {
        vendor: ['babel-polyfill'],
        extractCSS: {
            allChunks: true
        },
        plugins: [
            new webpack.ProvidePlugin({
                APP_CONF: resolve('./config/' + (process.env.APP_CONF || 'dev')),
                to: ['await-to-js', 'default']
            }),
        ]
    },
    env: {
        APP_VERSION: pkg.version
    },
    modules: [
        'cookie-universal-nuxt',
        '@nuxtjs/axios',
        '@nuxtjs/proxy'
    ],
    proxy: [
        ['/api/', { target: process.env.APP_API || 'http://api-test.lkker.com', pathRewrite: { '^/api/': '' }}]
    ],
    axios: {
        browserBaseURL: '/',
        retry: { retries: 3 }
    },
    css: [
        { 'src': '~/assets/icons/iconfont.css'},
        { 'src': '~/assets/icons/icon-facility.css'}
    ],
    loading: {
        color: '#4FC08D',
        failedColor: '#bf5050',
        duration: 1500
    },
    router: {
    },
    plugins: [
        '~/plugins/index',
        '~/business/index',
        '~/business/filters',
        '~/api/index',
        '~/components/index',
        '~/widgets/index'
    ],
    head: {
        meta: [
            { charset: 'utf-8' },
            { name: 'viewport', content: 'width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0' }
        ],
        link: [
            { rel: 'apple-touch-icon-precomposed', href: '/appicon.png' }
        ],
        __dangerouslyDisableSanitizers: ['script']
    }
}