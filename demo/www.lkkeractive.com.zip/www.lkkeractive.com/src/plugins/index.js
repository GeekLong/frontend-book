import Vue from 'vue';
import Url from './url';
Vue.prototype.$url = Vue.Url = Url;
