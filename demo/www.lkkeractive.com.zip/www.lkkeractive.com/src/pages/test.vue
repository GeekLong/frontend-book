<template>
    <div class="page">
    	空模版
    </div>
</template>

<script>
    export default {
    }
</script>

<style lang="scss">
</style>