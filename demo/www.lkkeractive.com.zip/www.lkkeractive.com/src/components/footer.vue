<template>
    <div class="footer">
        <div class="container">
            这是页面底部
        </div>
    </div>
</template>

<script>
    export default {
        data: function(){
            return {
               
            };
        },
        methods:{

        }
    }
</script>

<style lang="scss">
    .footer {
        width: 100%;
        height: 100px;
        line-height: 100px;
        background: #ccc;
        position: fixed;
        left: 0px;
        bottom: 0px;
    }
</style>