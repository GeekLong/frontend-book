import Vue from 'vue';
import loader from './wg-loader.vue';

const constructor = Vue.extend(loader);
let instance;

const wgLoader = (options = {}) => {
    if (!instance) {
        instance = new constructor({
            data: options
        });
        instance.vm = instance.$mount();

        if (typeof window != 'undefined') {
            document.body.appendChild(instance.vm.$el);
        }
        instance.vm.visible = true;
    }
    else {
        instance.vm.visible = true;
    }

    return instance;
};

export default wgLoader;