module.exports = {
    apps: [{
        name: "www.lkkeractive.com",
        script: "npm",
        args: "run start",
        watch: true,
        env: {
            APP_API: "baseurl"
        }
    }]
}