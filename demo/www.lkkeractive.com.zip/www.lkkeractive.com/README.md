# 安装

```
yarn / yarn install
yarn install --production
```

# 开发启动

```
yarn dev
```

# 编译

```
yarn build
```

# 参考
如何启动、测试正式环境启动、环境变量等，请参考：http://10.5.201.186/web-front-end/www.trip.io