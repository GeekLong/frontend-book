export default function(date, fmt){
    
    //if(!date || typeof window ==="undefined") return "";
    
    fmt = fmt || "yyyy-MM-dd";
    //date = date || new Date();
    
    if(typeof date != 'object'){
        date = new Date(date)
    }
    
    var t = [date.getFullYear(), date.getMonth(), date.getDate(), date.getHours(), date.getMinutes(), date.getSeconds(), date.getMilliseconds()],
        o = {
            "M+": t[1] + 1,
            "d+": t[2],
            "h+": t[3],
            "m+": t[4],
            "s+": t[5],
            "q+": Math.floor((t[1] + 3) / 3),
            "S": t[6]
        };
    if (/(y+)/.test(fmt)) fmt = fmt.replace(RegExp.$1, (t[0] + "").substr(4 - RegExp.$1.length));
    for (var k in o) {
        if (new RegExp("(" + k + ")").test(fmt)) fmt = fmt.replace(RegExp.$1, RegExp.$1.length == 1 ? o[k] : ("00" + o[k]).substr(("" + o[k]).length));
    }
    return fmt;

}