<template>
    <div class="page teambuild-order">
    	<nav-bar></nav-bar>
        <active-case></active-case>
        <foot></foot>
    </div>
</template>

<script>
	import activeCase from "./.active-case.vue"
    export default {
       components:{
           activeCase
       },
       head() {
            return {
                title: "活动页面",
                meta :[
                    { name: 'keywords', content:'活动页面' },
                    { name: 'description', content:'活动页面' },
                ]
            }
        },
    }
</script>

<style lang="scss">
</style>