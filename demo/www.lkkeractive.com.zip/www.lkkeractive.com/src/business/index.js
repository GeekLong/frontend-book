import Config from './config';
import HttpInterceptor from './interceptor/http';

export default function ({ $axios, redirect, app }, inject) {
    Config({ app }, inject);
    HttpInterceptor({ $axios, redirect, app });
}