module.exports = {
    name: 'DEV',
    url: {
        lkkerpc: 'http://localhost:8080'
    }
}