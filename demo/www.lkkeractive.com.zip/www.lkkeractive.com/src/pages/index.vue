<script>
import Index from '~/pages/active/index'
export default Index
</script>
