<template>
    <div v-if="visible">
        <div class="wg-loader"></div>
        <div class="loader-mask"></div>
    </div>
</template>

<script>
    export default {
        data: function() {
            return {
                visible: false
            }
        },
        methods:{
            close: function() {
                this.visible = false;
            }
        }
    }
</script>

<style lang="scss">
    .wg-loader {
        padding: 5px;
        border-radius: 5px;
        background-color: #f5f5f5;
        color: #fff;
        height: 114px;
        width: 114px;
        position: fixed;
        top: 50%;
        left: 50%;
        margin-top: -63px;
        margin-left: -63px;
        border: 1px solid #e8e8e8;
        z-index: 99999;
        background-image: url(/images/loader.gif);
        background-repeat: no-repeat;
        background-size: 95px 95px;
        background-position: center;
        -webkit-transition: .2s opacity linear;
        transition: .2s opacity linear;
        box-shadow: 0 0px 0px rgba(0,0,0,.25);

    }
    .loader-mask {
        position: fixed;
        top: 0;
        left: 0;
        height: 100%;
        width: 100%;
        background-color: #000;
        opacity: .2;
        z-index: 10000;
    }
</style>