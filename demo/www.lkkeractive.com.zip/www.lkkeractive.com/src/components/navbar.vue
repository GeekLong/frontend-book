<template>
    <div class="navbar">
        <div class="container">
            这是Navbar页面头部
        </div>
    </div>

</template>

<script>
    
    export default {
        components: {},
        data: function() {
            return {
            }
        },
        mounted: function(){

        },
        methods: {

        }
    }
</script>

<style lang="scss">
    .navbar {
        height: 100px;
        line-height: 100px;
        background: #ccc;
    }
</style>