module.exports = {
    name: 'TEST',
    url: {
        lkkerpc: 'http://0.0.0.0/'
    }
}