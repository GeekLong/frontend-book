<template>
    <div class="case-container">
    	<div class="container">
			这是活动页面的子页面
    	</div>
    </div>
</template>
<script>
    export default {
    	data:function(){
    		return {
    			
    		}
    	},
    	mounted:function(){
			
    	},
       	methods:{
			
       	}
    }
</script>

<style lang="scss">
	.case-container{
		height: 600px;
	}
	
		
</style>