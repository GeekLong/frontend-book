import Vue from 'vue';
import navBar from './navbar.vue';
import foot from './footer.vue';

Vue.component('nav-bar', navBar);
Vue.component('foot', foot);