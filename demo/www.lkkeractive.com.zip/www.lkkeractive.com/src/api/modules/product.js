
export default ({ app, $axios }) => {
    let ApiProduct = {
        getQrcode: (params) => {
            return to($axios.get('/api/mediaservice/qrcode', {
                params: params
            }));
        },
    };

    return ApiProduct;
}