export default {
    query: function (href) {
        if(typeof window ==="undefined") return;

        var args = {},
            queryArr = [],
            queryArrItem = [],
            name, value;
        href = href || window.location.href;
        var queryStr = href.split("?")[1] ? href.split("?")[1].split("#")[0] ? href.split("?")[1].split("#")[0] : "" : "";
        if (queryStr === "") {
            return {};
        } else {
            queryArr = queryStr.split("&");
            for (var i = queryArr.length - 1; i >= 0; i--) {
                queryArrItem = queryArr[i].split("=");
                name = decodeURIComponent(queryArrItem[0]);
                value = decodeURIComponent(queryArrItem[1]);
                if (args[name]) {
                    var isArray = Object.prototype.toString.call(args[name]) === '[object Array]';
                    if (!isArray) {
                        args[name] = [args[name]];
                    }
                    args[name].push(value);
                } else {
                    args[name] = value || "";
                }

            }
            return args;
        }
    },
    serialize: function (obj) {
        var str = [];
        for (var p in obj) {
            var isArray = Object.prototype.toString.call(obj[p]) === '[object Array]';
            if (obj[p]) {
                var value = "";
                if(isArray) {
                    for(var i = 0; i < obj[p].length;i++) {
                        value = encodeURIComponent(obj[p][i]);
                        str.push(encodeURIComponent(p) + "=" + value);
                    } 
                }
                else {
                    value = encodeURIComponent(obj[p]);
                    str.push(encodeURIComponent(p) + "=" + value);
                }
                
            }
        }
        return str.join("&");
    }
}