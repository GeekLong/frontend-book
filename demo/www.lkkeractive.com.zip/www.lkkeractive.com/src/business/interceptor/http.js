export default function ({ $axios, redirect, app }) {

    $axios.onRequest(config => {
       // console.log('Making request to ' + config.url);
        let user = app.$user.get();

        config.timeout = process.browser ? 10000 : 10000;

        config.headers['source'] = 'lkker';
        config.headers['market'] = 'lkker';
        config.headers['clientType'] = /Android|webOS|iPhone|iPod|BlackBerry/i.test(navigator.userAgent) ? 'h5':'web';
        config.headers['appVersion'] = process.env.APP_VERSION;
        
    })

    $axios.onError(error => {
        const code = parseInt(error.response && error.response.status)
    })
}