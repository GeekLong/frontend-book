import cookieUniversal from 'cookie-universal'

export default ({ req, res }, inject) => {
  const options = {
  "alias": "cookies"
}
  inject(options.alias, cookieUniversal(req, res))
}
