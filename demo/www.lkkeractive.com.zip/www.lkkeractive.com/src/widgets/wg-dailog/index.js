import Vue from 'vue';
import dailog from './wg-dailog.vue';

const constructor = Vue.extend(dailog);

const wgDailog = (options = {}) => {
    let instance = new constructor({
        data: options
    });
    instance.vm = instance.$mount();

    document.body.appendChild(instance.vm.$el);
    instance.vm.visible = true;

    return instance;
};

export default wgDailog;