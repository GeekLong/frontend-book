<template>
    <div class="wg-dialog" v-if="visible">
        <div class="dialog-mask"></div>
        
        <div class="dialog-view">
            <span class="close"
                @click="close()">×</span>
            <div class="dialog-title"
                v-if="title">
                {{title}}
            </div>
            <div class="dialog-body"
                :class="{'dialog-body-auto':auto}">
                {{content}}
            </div>
            <div class="dialog-footer">
                <button class="btn" @click="close()">确定</button>
            </div>
        </div>
    </div>
</template>

<script>
    export default {
        data: function() {
            return {
                visible: true,
                title: '信息',
                content: '内容'
            }
        },
        mounted: function() {
            if(typeof window === "undefined") return;
            this.visible = true;
            this.init();
        },
        methods: {
            init: function() {
                let dailog = this.$el.children[1];
                let screenWidth = document.body.offsetWidth;
                setTimeout(()=> {
                    let height = dailog.clientHeight,
                        width = dailog.clientWidth;
                    dailog.style.top = '40%';
                    dailog.style.marginTop = (height / -2) + 'px';
                    dailog.style.left = '50%';
                    dailog.style.marginLeft = (width / -2) + 'px';
                },10);
            },
            close: function() {
                this.visible = false;
            }
        }
    }
</script>

<style lang="scss">
    .wg-dialog {
        .dialog-mask {
            position: fixed;
            top: 0;
            left: 0;
            height: 100%;
            width: 100%;
            background-color: #000;
            opacity: .7;
            z-index: 10000;
        }
        .dialog-view {
            position: fixed;
            left: 50%;
            margin-left: -250px;
            width: 500px;
            min-height: 180px;
            border: 1px solid #e8e8e8;
            border-radius: 2px;
            box-shadow: 0 2px 7px rgba(0, 0, 0, .25);
            background-color: #fff;
            -webkit-transition: .2s opacity linear;
            transition: .2s opacity linear;
            z-index: 10001;
            .close {
                position: absolute;
                right: 8px;
                top:20px;
                height: 22px;
                width: 22px;
                font-size: 30px;
                line-height: 15px;
                color: #333;
                text-shadow: 0 1px 0 #fff;
                text-align: center;
                cursor: pointer;
                user-select: none;
                -webkit-user-select: none;
                opacity: .2;
                z-index: 999;
            }
            .dialog-title {
                line-height: 22px;
                min-height: 22px;
                padding: 19px 40px 19px 19px;
                font-size: 18px;
                color: #333;
                border-bottom: 1px solid #eee;
                position: relative;
                text-align: left;
                color: #000;
            }
            .dialog-body {
                margin: 35px 19px;
                line-height: 22px;
                font-size: 16px;
                color: #666;
                max-height: 150px;
                overflow-y:auto;
            }
            .dialog-footer{
                padding: 15px 19px;
                line-height:16px;
                min-height: 40px;
                background-color: #F8F8F6;
                text-align: right;
                .btn{
                    width: 100px;
                    height: 40px;
                    background: #ff556f;
                    color: #fff;
                    line-height: 40px;
                    text-align: center;
                    font-size: 16px;
                    cursor: pointer;
                }
            }
        }
    }
</style>