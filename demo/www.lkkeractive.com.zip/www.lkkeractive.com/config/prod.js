module.exports = {
    name: 'PROD',
    url: {
        lkkerpc: 'https://www.lkker.com/'
    }
}