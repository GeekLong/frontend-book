import ApiProduct from './modules/product';
export default ({ app, $axios }, inject) => {
    let api = {
        product: ApiProduct({ app, $axios }),
    };
    app.$api = api;
    inject('api', api);
}