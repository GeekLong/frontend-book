export default function ({ app }, inject) {
    let config = {
        name: ''
    };

    if (!APP_CONF) {
        console.error('APP_CONF import failed!Please check your webpack, if config ProvidePlugin with APP_CONF');
    }
    else if (APP_CONF.name != 'prod') {
        console.log(`APP_CONF import success! This is ${APP_CONF.name} config environment.`);
    }

    config = {
        name: APP_CONF.name,
        url: APP_CONF.url,
        domain: 'lkker',
        keys: {
            user: 'user',
            channelid: 'channelid'
        }
    };

    app.$config = config;

    inject('config', config);
}