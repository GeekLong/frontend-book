import Vue from 'vue';
import Date from './filters/date';
Vue.filter('date', Date);
